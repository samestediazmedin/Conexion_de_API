// ════════════════════════════════════════════════════════
//  WeatherLux — MongoDB Seed Script
//  Ejecutar: mongosh weatherlux_seed.js
//  O desde Compass: abrir Shell y pegar el contenido
// ════════════════════════════════════════════════════════

use("weatherlux_db");

print("\n🗄️  WeatherLux — Creando base de datos...\n");

// Limpiar colecciones (solo desarrollo)
["users","search_history","weather_cache","weather_alerts","api_logs"]
  .forEach(c => { db[c].drop(); print(`   🗑  ${c} limpiada`); });

print("\n📐 Creando índices...\n");

// ── users ──────────────────────────────────────────────
db.users.createIndex({ email: 1 },    { unique: true, name: "idx_users_email_unique" });
db.users.createIndex({ role: 1 },     { name: "idx_users_role" });
db.users.createIndex({ isActive: 1 }, { name: "idx_users_isActive" });
print("   ✓ users");

// ── search_history ─────────────────────────────────────
db.search_history.createIndex(
  { userId: 1, searchedAt: -1 },
  { name: "idx_history_user_date" }
);
db.search_history.createIndex({ city: 1 }, { name: "idx_history_city" });
db.search_history.createIndex(
  { searchedAt: 1 },
  {
    expireAfterSeconds: 604800,          // 7 días
    partialFilterExpression: { userId: null },
    name: "idx_history_ttl_anon_7d"
  }
);
print("   ✓ search_history");

// ── weather_cache ──────────────────────────────────────
db.weather_cache.createIndex(
  { cacheKey: 1 }, { unique: true, name: "idx_cache_key_unique" }
);
db.weather_cache.createIndex(
  { expiresAt: 1 }, { expireAfterSeconds: 0, name: "idx_cache_ttl_30m" }
);
print("   ✓ weather_cache");

// ── weather_alerts ─────────────────────────────────────
db.weather_alerts.createIndex(
  { userId: 1, isActive: 1 },
  { name: "idx_alerts_user_active" }
);
print("   ✓ weather_alerts");

// ── api_logs ───────────────────────────────────────────
db.api_logs.createIndex({ requestedAt: -1 }, { name: "idx_logs_date_desc" });
db.api_logs.createIndex({ endpoint: 1 },     { name: "idx_logs_endpoint" });
db.api_logs.createIndex(
  { requestedAt: 1 },
  { expireAfterSeconds: 2592000, name: "idx_logs_ttl_30d" } // 30 días
);
print("   ✓ api_logs");

// ════════════════════════════════════════════════════════
//  DATOS DE PRUEBA
// ════════════════════════════════════════════════════════
print("\n🌱 Insertando datos de prueba...\n");

const adminId = new ObjectId();
const userId  = new ObjectId();
const now     = new Date();

// Usuarios
db.users.insertMany([
  {
    _id: adminId,
    name: "Admin WeatherLux",
    email: "admin@weatherlux.com",
    // password: Admin1234! (hash BCrypt workFactor=12)
    passwordHash: "$2a$12$placeholder_cambiar_al_iniciar_app",
    role: "admin",
    isActive: true,
    preferences: {
      temperatureUnit: "celsius",
      language: "es",
      defaultCity: "Bogotá",
      notificationsEnabled: false
    },
    favoriteCities: [
      { name: "Bogotá",  country: "Colombia", latitude: 4.6097,  longitude: -74.0817, addedAt: now },
      { name: "Madrid",  country: "España",   latitude: 40.4168, longitude: -3.7038,  addedAt: now }
    ],
    createdAt: now,
    lastLoginAt: now
  },
  {
    _id: userId,
    name: "Usuario Demo",
    email: "demo@weatherlux.com",
    passwordHash: "$2a$12$placeholder_cambiar_al_iniciar_app",
    role: "user",
    isActive: true,
    preferences: {
      temperatureUnit: "celsius",
      language: "es",
      defaultCity: null,
      notificationsEnabled: true
    },
    favoriteCities: [
      { name: "Medellín", country: "Colombia", latitude: 6.2442, longitude: -75.5812, addedAt: now }
    ],
    createdAt: now,
    lastLoginAt: null
  }
]);
print("   ✓ 2 usuarios creados");

// Historial de búsquedas
db.search_history.insertMany([
  {
    userId: userId.toString(),
    city: "Bogotá", country: "Colombia",
    latitude: 4.6097, longitude: -74.0817,
    weatherSnapshot: { temperature: 14.5, weatherCode: 2, condition: "Parcialmente nublado", humidity: 78, windSpeed: 12.3 },
    searchedAt: new Date(Date.now() - 3600000),
    ipAddress: "127.0.0.1"
  },
  {
    userId: userId.toString(),
    city: "Cartagena", country: "Colombia",
    latitude: 10.3910, longitude: -75.4794,
    weatherSnapshot: { temperature: 32.1, weatherCode: 0, condition: "Cielo despejado", humidity: 82, windSpeed: 18.7 },
    searchedAt: new Date(Date.now() - 7200000),
    ipAddress: "127.0.0.1"
  },
  {
    userId: null,   // búsqueda anónima — expira en 7 días (TTL)
    city: "Barranquilla", country: "Colombia",
    latitude: 10.9639, longitude: -74.7964,
    weatherSnapshot: { temperature: 30.0, weatherCode: 1, condition: "Mayormente despejado", humidity: 75, windSpeed: 20.0 },
    searchedAt: now,
    ipAddress: "192.168.1.100"
  }
]);
print("   ✓ 3 búsquedas en historial");

// Alerta meteorológica
db.weather_alerts.insertOne({
  userId: userId.toString(),
  city: "Bogotá",
  latitude: 4.6097,
  longitude: -74.0817,
  conditionType: "temp_below",
  threshold: 8.0,
  isActive: true,
  lastTriggeredAt: null,
  createdAt: now
});
print("   ✓ 1 alerta configurada");

// Logs de API
db.api_logs.insertMany([
  { endpoint: "/api/weather", city: "Bogotá",    userId: userId.toString(), statusCode: 200, responseTimeMs: 145, cacheHit: false, ipAddress: "127.0.0.1", requestedAt: new Date(Date.now() - 600000) },
  { endpoint: "/api/weather", city: "Bogotá",    userId: userId.toString(), statusCode: 200, responseTimeMs: 8,   cacheHit: true,  ipAddress: "127.0.0.1", requestedAt: new Date(Date.now() - 300000) },
  { endpoint: "/api/weather", city: "Medellín",  userId: null,             statusCode: 200, responseTimeMs: 201, cacheHit: false, ipAddress: "10.0.0.1",  requestedAt: now },
  { endpoint: "/api/auth/login", city: null,     userId: null,             statusCode: 200, responseTimeMs: 320, cacheHit: false, ipAddress: "127.0.0.1", requestedAt: now }
]);
print("   ✓ 4 logs de API");

// ════════════════════════════════════════════════════════
//  RESUMEN FINAL
// ════════════════════════════════════════════════════════
print("\n═══════════════════════════════════════════════");
print("✅  WeatherLux DB lista — weatherlux_db");
print("═══════════════════════════════════════════════");
print("📦  Colecciones:");
db.getCollectionNames().forEach(name => {
  const n = db[name].countDocuments();
  const i = db[name].getIndexes().length;
  print(`    • ${name.padEnd(20)} ${n} doc(s)  ${i} índice(s)`);
});
print("───────────────────────────────────────────────");
print("👤  admin@weatherlux.com  (role: admin)");
print("👤  demo@weatherlux.com   (role: user)");
print("───────────────────────────────────────────────");
print("⚠️   Los passwordHash son placeholders.");
print("    Usa POST /api/auth/register para crear");
print("    usuarios reales con BCrypt correcto.");
print("═══════════════════════════════════════════════\n");
