using MongoDB.Bson;
using MongoDB.Driver;
using WeatherLux.Core.Interfaces;
using WeatherLux.Core.Models;
using WeatherLux.Infrastructure.Database.Configuration;
using WeatherLux.Infrastructure.Database.Models;

namespace WeatherLux.Infrastructure.Database.Repositories;

// ════════════════════════════════════════════════════════
//  USER REPOSITORY
// ════════════════════════════════════════════════════════
public class UserRepository : IUserRepository
{
    private readonly IMongoCollection<UserDocument> _col;

    public UserRepository(WeatherLuxDbContext ctx) => _col = ctx.Users;

    public async Task<User?> GetByIdAsync(string id)
    {
        var doc = await _col.Find(u => u.Id == id).FirstOrDefaultAsync();
        return doc is null ? null : Map(doc);
    }

    public async Task<User?> GetByEmailAsync(string email)
    {
        var doc = await _col.Find(u => u.Email == email.ToLowerInvariant()).FirstOrDefaultAsync();
        return doc is null ? null : Map(doc);
    }

    public async Task<bool> EmailExistsAsync(string email) =>
        await _col.Find(u => u.Email == email.ToLowerInvariant()).AnyAsync();

    public async Task<User> CreateAsync(User user)
    {
        var doc = MapToDoc(user);
        doc.Email     = doc.Email.ToLowerInvariant();
        doc.CreatedAt = DateTime.UtcNow;
        await _col.InsertOneAsync(doc);
        user.Id = doc.Id;
        return user;
    }

    public async Task UpdateAsync(string id, User user) =>
        await _col.ReplaceOneAsync(u => u.Id == id, MapToDoc(user));

    public async Task AddFavoriteCityAsync(string userId, FavoriteCity city)
    {
        var cityDoc = new FavoriteCityDocument
        {
            Name = city.Name, Country = city.Country,
            Latitude = city.Latitude, Longitude = city.Longitude,
            AddedAt = DateTime.UtcNow
        };
        var update = Builders<UserDocument>.Update.AddToSet(u => u.FavoriteCities, cityDoc);
        await _col.UpdateOneAsync(u => u.Id == userId, update);
    }

    public async Task RemoveFavoriteCityAsync(string userId, string cityName)
    {
        var pull = Builders<UserDocument>.Update.PullFilter(
            u => u.FavoriteCities,
            Builders<FavoriteCityDocument>.Filter.Eq(c => c.Name, cityName));
        await _col.UpdateOneAsync(u => u.Id == userId, pull);
    }

    public async Task UpdateLastLoginAsync(string userId)
    {
        var update = Builders<UserDocument>.Update.Set(u => u.LastLoginAt, DateTime.UtcNow);
        await _col.UpdateOneAsync(u => u.Id == userId, update);
    }

    // ── Mappers ───────────────────────────────────────────
    private static User Map(UserDocument d) => new()
    {
        Id = d.Id, Name = d.Name, Email = d.Email,
        PasswordHash = d.PasswordHash, Role = d.Role, IsActive = d.IsActive,
        CreatedAt = d.CreatedAt, LastLoginAt = d.LastLoginAt,
        Preferences = new()
        {
            TemperatureUnit      = d.Preferences.TemperatureUnit,
            Language             = d.Preferences.Language,
            DefaultCity          = d.Preferences.DefaultCity,
            NotificationsEnabled = d.Preferences.NotificationsEnabled
        },
        FavoriteCities = d.FavoriteCities.Select(c => new FavoriteCity
        {
            Name = c.Name, Country = c.Country,
            Latitude = c.Latitude, Longitude = c.Longitude, AddedAt = c.AddedAt
        }).ToList()
    };

    private static UserDocument MapToDoc(User u) => new()
    {
        Id = u.Id, Name = u.Name, Email = u.Email,
        PasswordHash = u.PasswordHash, Role = u.Role, IsActive = u.IsActive,
        CreatedAt = u.CreatedAt, LastLoginAt = u.LastLoginAt,
        Preferences = new()
        {
            TemperatureUnit      = u.Preferences.TemperatureUnit,
            Language             = u.Preferences.Language,
            DefaultCity          = u.Preferences.DefaultCity,
            NotificationsEnabled = u.Preferences.NotificationsEnabled
        },
        FavoriteCities = u.FavoriteCities.Select(c => new FavoriteCityDocument
        {
            Name = c.Name, Country = c.Country,
            Latitude = c.Latitude, Longitude = c.Longitude, AddedAt = c.AddedAt
        }).ToList()
    };
}

// ════════════════════════════════════════════════════════
//  SEARCH HISTORY REPOSITORY
// ════════════════════════════════════════════════════════
public class SearchHistoryRepository : ISearchHistoryRepository
{
    private readonly IMongoCollection<SearchHistoryDocument> _col;

    public SearchHistoryRepository(WeatherLuxDbContext ctx) => _col = ctx.SearchHistory;

    public async Task SaveAsync(SearchHistory entry)
    {
        var doc = new SearchHistoryDocument
        {
            UserId    = entry.UserId,
            City      = entry.City,
            Country   = entry.Country,
            Latitude  = entry.Latitude,
            Longitude = entry.Longitude,
            IpAddress = entry.IpAddress,
            SearchedAt = DateTime.UtcNow,
            WeatherSnapshot = new WeatherSnapshotDocument
            {
                Temperature = entry.WeatherSnapshot.Temperature,
                WeatherCode = entry.WeatherSnapshot.WeatherCode,
                Condition   = entry.WeatherSnapshot.Condition,
                Humidity    = entry.WeatherSnapshot.Humidity,
                WindSpeed   = entry.WeatherSnapshot.WindSpeed,
            }
        };
        await _col.InsertOneAsync(doc);
    }

    public async Task<List<SearchHistory>> GetByUserAsync(string userId, int limit = 20)
    {
        var docs = await _col
            .Find(s => s.UserId == userId)
            .SortByDescending(s => s.SearchedAt)
            .Limit(limit)
            .ToListAsync();

        return docs.Select(d => new SearchHistory
        {
            Id = d.Id, UserId = d.UserId, City = d.City, Country = d.Country,
            Latitude = d.Latitude, Longitude = d.Longitude,
            SearchedAt = d.SearchedAt, IpAddress = d.IpAddress,
            WeatherSnapshot = new WeatherSnapshot
            {
                Temperature = d.WeatherSnapshot.Temperature,
                WeatherCode = d.WeatherSnapshot.WeatherCode,
                Condition   = d.WeatherSnapshot.Condition,
                Humidity    = d.WeatherSnapshot.Humidity,
                WindSpeed   = d.WeatherSnapshot.WindSpeed
            }
        }).ToList();
    }

    public async Task<List<(string City, string Country, long Count)>> GetTrendingAsync(int limit = 10)
    {
        var since = DateTime.UtcNow.AddHours(-24);

        var pipeline = new[]
        {
            new BsonDocumentPipelineStageDefinition<SearchHistoryDocument, BsonDocument>(
                new BsonDocument("$match", new BsonDocument("searchedAt",
                    new BsonDocument("$gte", since)))),

            new BsonDocumentPipelineStageDefinition<SearchHistoryDocument, BsonDocument>(
                new BsonDocument("$group", new BsonDocument
                {
                    { "_id",   new BsonDocument { { "city", "$city" }, { "country", "$country" } } },
                    { "count", new BsonDocument("$sum", 1) }
                })),

            new BsonDocumentPipelineStageDefinition<SearchHistoryDocument, BsonDocument>(
                new BsonDocument("$sort", new BsonDocument("count", -1))),

            new BsonDocumentPipelineStageDefinition<SearchHistoryDocument, BsonDocument>(
                new BsonDocument("$limit", limit)),
        };

        var results = await _col
            .Aggregate(PipelineDefinition<SearchHistoryDocument, BsonDocument>.Create(pipeline))
            .ToListAsync();

        return results
            .Select(r => (
                r["_id"]["city"].AsString,
                r["_id"]["country"].AsString,
                (long)r["count"].AsInt32
            )).ToList();
    }

    public async Task DeleteUserHistoryAsync(string userId) =>
        await _col.DeleteManyAsync(s => s.UserId == userId);
}

// ════════════════════════════════════════════════════════
//  WEATHER CACHE REPOSITORY
// ════════════════════════════════════════════════════════
public class WeatherCacheRepository : IWeatherCacheRepository
{
    private readonly IMongoCollection<WeatherCacheDocument> _col;

    public WeatherCacheRepository(WeatherLuxDbContext ctx) => _col = ctx.WeatherCache;

    private static string Key(double lat, double lon) =>
        $"{Math.Round(lat, 2)}_{Math.Round(lon, 2)}";

    public async Task<WeatherCache?> GetAsync(double lat, double lon)
    {
        var key = Key(lat, lon);
        var doc = await _col.Find(c => c.CacheKey == key).FirstOrDefaultAsync();
        if (doc is null || doc.ExpiresAt <= DateTime.UtcNow) return null;

        return new WeatherCache
        {
            Id = doc.Id, CacheKey = doc.CacheKey, City = doc.City,
            Country = doc.Country, Latitude = doc.Latitude, Longitude = doc.Longitude,
            Data = doc.Data, FetchedAt = doc.FetchedAt, ExpiresAt = doc.ExpiresAt
        };
    }

    public async Task SetAsync(WeatherCache entry)
    {
        var doc = new WeatherCacheDocument
        {
            CacheKey  = Key(entry.Latitude, entry.Longitude),
            City      = entry.City, Country = entry.Country,
            Latitude  = entry.Latitude, Longitude = entry.Longitude,
            Data      = entry.Data,
            FetchedAt = DateTime.UtcNow,
            ExpiresAt = DateTime.UtcNow.AddMinutes(30)
        };

        var filter  = Builders<WeatherCacheDocument>.Filter.Eq(c => c.CacheKey, doc.CacheKey);
        var options = new ReplaceOptions { IsUpsert = true };
        await _col.ReplaceOneAsync(filter, doc, options);
    }

    public async Task InvalidateAsync(double lat, double lon) =>
        await _col.DeleteOneAsync(c => c.CacheKey == Key(lat, lon));
}

// ════════════════════════════════════════════════════════
//  ALERT REPOSITORY
// ════════════════════════════════════════════════════════
public class AlertRepository : IAlertRepository
{
    private readonly IMongoCollection<WeatherAlertDocument> _col;

    public AlertRepository(WeatherLuxDbContext ctx) => _col = ctx.WeatherAlerts;

    public async Task<WeatherAlert> CreateAsync(WeatherAlert alert)
    {
        var doc = new WeatherAlertDocument
        {
            UserId        = alert.UserId,
            City          = alert.City,
            Latitude      = alert.Latitude,
            Longitude     = alert.Longitude,
            ConditionType = alert.Condition.Type,
            Threshold     = alert.Condition.Threshold,
            IsActive      = true,
            CreatedAt     = DateTime.UtcNow
        };
        await _col.InsertOneAsync(doc);
        alert.Id = doc.Id;
        return alert;
    }

    public async Task<List<WeatherAlert>> GetByUserAsync(string userId)
    {
        var docs = await _col.Find(a => a.UserId == userId)
                             .SortByDescending(a => a.CreatedAt)
                             .ToListAsync();
        return docs.Select(Map).ToList();
    }

    public async Task<WeatherAlert?> GetByIdAsync(string id)
    {
        var doc = await _col.Find(a => a.Id == id).FirstOrDefaultAsync();
        return doc is null ? null : Map(doc);
    }

    public async Task UpdateAsync(string id, WeatherAlert alert) =>
        await _col.ReplaceOneAsync(a => a.Id == id, new WeatherAlertDocument
        {
            Id = id, UserId = alert.UserId, City = alert.City,
            Latitude = alert.Latitude, Longitude = alert.Longitude,
            ConditionType = alert.Condition.Type, Threshold = alert.Condition.Threshold,
            IsActive = alert.IsActive, LastTriggeredAt = alert.LastTriggeredAt,
            CreatedAt = alert.CreatedAt
        });

    public async Task DeleteAsync(string id) =>
        await _col.DeleteOneAsync(a => a.Id == id);

    public async Task<List<WeatherAlert>> GetActiveAlertsAsync()
    {
        var docs = await _col.Find(a => a.IsActive).ToListAsync();
        return docs.Select(Map).ToList();
    }

    private static WeatherAlert Map(WeatherAlertDocument d) => new()
    {
        Id = d.Id, UserId = d.UserId, City = d.City,
        Latitude = d.Latitude, Longitude = d.Longitude,
        IsActive = d.IsActive, LastTriggeredAt = d.LastTriggeredAt, CreatedAt = d.CreatedAt,
        Condition = new AlertCondition { Type = d.ConditionType, Threshold = d.Threshold }
    };
}

// ════════════════════════════════════════════════════════
//  API LOG REPOSITORY
// ════════════════════════════════════════════════════════
public class ApiLogRepository : IApiLogRepository
{
    private readonly IMongoCollection<ApiLogDocument> _col;

    public ApiLogRepository(WeatherLuxDbContext ctx) => _col = ctx.ApiLogs;

    public async Task LogAsync(ApiLog log) =>
        await _col.InsertOneAsync(new ApiLogDocument
        {
            Endpoint       = log.Endpoint,
            City           = log.City,
            UserId         = log.UserId,
            StatusCode     = log.StatusCode,
            ResponseTimeMs = log.ResponseTimeMs,
            CacheHit       = log.CacheHit,
            IpAddress      = log.IpAddress,
            RequestedAt    = DateTime.UtcNow
        });

    public async Task<(long Total, long CacheHits, double AvgMs, long Errors)> GetStatsAsync(
        DateTime from, DateTime to)
    {
        var filter = Builders<ApiLogDocument>.Filter.And(
            Builders<ApiLogDocument>.Filter.Gte(l => l.RequestedAt, from),
            Builders<ApiLogDocument>.Filter.Lte(l => l.RequestedAt, to));

        var logs      = await _col.Find(filter).ToListAsync();
        var total     = (long)logs.Count;
        var cacheHits = (long)logs.Count(l => l.CacheHit);
        var avgMs     = total > 0 ? logs.Average(l => l.ResponseTimeMs) : 0;
        var errors    = (long)logs.Count(l => l.StatusCode >= 400);

        return (total, cacheHits, avgMs, errors);
    }
}
