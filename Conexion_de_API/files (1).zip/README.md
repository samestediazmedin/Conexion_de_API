# 🌤️ WeatherLux — Backend Completo

> .NET 8 Web API · MongoDB · Open-Meteo · JWT Auth

---

## 📁 Estructura del Proyecto

```
WeatherLux/
├── WeatherLux.sln
│
├── WeatherLux.API/                        ← Capa de presentación
│   ├── Controllers/
│   │   └── Controllers.cs                 (Weather, Auth, Users, Admin)
│   ├── Program.cs                         (DI, JWT, CORS, Swagger)
│   ├── appsettings.json
│   └── appsettings.Development.json
│
├── WeatherLux.Core/                       ← Dominio (sin dependencias externas)
│   ├── Models/
│   │   └── Models.cs                      (User, SearchHistory, WeatherCache…)
│   ├── DTOs/
│   │   └── DTOs.cs                        (Request/Response records)
│   └── Interfaces/
│       └── Interfaces.cs                  (IWeatherService, IUserService…)
│
└── WeatherLux.Infrastructure/             ← Implementaciones (MongoDB, HTTP)
    ├── Database/
    │   ├── Configuration/
    │   │   └── DbContext.cs               (WeatherLuxDbContext + índices)
    │   ├── Models/
    │   │   └── Documents.cs               (BSON documents con atributos)
    │   ├── Repositories/
    │   │   └── Repositories.cs            (User, History, Cache, Alert, Log)
    │   └── Seed/
    │       └── weatherlux_seed.js         (Script mongosh)
    └── Services/
        ├── WeatherService.cs              (Cache → Open-Meteo → DB)
        └── UserService.cs                 (BCrypt + JWT)
```

---

## 🗄️ Base de Datos MongoDB — `weatherlux_db`

| Colección        | Descripción                        | TTL automático        |
|------------------|------------------------------------|-----------------------|
| `users`          | Usuarios, preferencias, favoritos  | —                     |
| `search_history` | Cada búsqueda con snapshot clima   | 7 días (anónimas)     |
| `weather_cache`  | Cache de Open-Meteo                | **30 minutos**        |
| `weather_alerts` | Alertas por temperatura/lluvia     | —                     |
| `api_logs`       | Métricas de rendimiento y uso      | 30 días               |

### Flujo de cache inteligente
```
GET /api/weather?city=Bogotá
  → weather_cache (MongoDB)? ✅ → responde en ~5ms (cache hit)
  → weather_cache (MongoDB)? ❌ → Open-Meteo API (~200ms)
                                → guarda en cache 30 min
                                → guarda en search_history
                                → guarda api_log
                                → responde
```

---

## 🚀 Instalación Desde Cero

### 1. Prerrequisitos
```bash
# .NET 8 SDK
https://dotnet.microsoft.com/download/dotnet/8.0

# MongoDB Community (local)
https://www.mongodb.com/try/download/community

# O usar MongoDB Atlas (gratis)
https://www.mongodb.com/atlas
```

### 2. Crear el proyecto
```bash
# Clonar / copiar archivos, luego:
cd WeatherLux
dotnet restore
dotnet build
```

### 3. Configurar MongoDB
```bash
# Opción A: Local (por defecto)
# MongoDB debe estar corriendo en localhost:27017

# Opción B: Atlas
# Editar WeatherLux.API/appsettings.json:
# "ConnectionString": "mongodb+srv://user:pass@cluster.xxxxx.mongodb.net/weatherlux_db"
```

### 4. Seed de la base de datos
```bash
mongosh WeatherLux.Infrastructure/Database/Seed/weatherlux_seed.js
```

### 5. Ejecutar
```bash
cd WeatherLux.API
dotnet run

# API disponible en:
# https://localhost:7001
# http://localhost:5001
# Swagger: https://localhost:7001/swagger
```

---

## 🌐 Endpoints API

### Clima (público)
```
GET  /api/weather?city=Bogotá
GET  /api/weather/coordinates?lat=4.6&lon=-74.08
```

### Autenticación
```
POST /api/auth/register   { name, email, password }
POST /api/auth/login      { email, password }
```

### Usuario (requiere JWT)
```
GET    /api/users/me
GET    /api/users/me/history?limit=20
POST   /api/users/me/favorites    { name, country, latitude, longitude }
DELETE /api/users/me/favorites/{cityName}
```

### Admin (requiere role=admin)
```
GET  /api/admin/stats?hours=24
```

### Health
```
GET  /health
```

---

## 🔐 JWT en el Frontend

```javascript
// Login
const res = await fetch('https://localhost:7001/api/auth/login', {
  method: 'POST',
  headers: { 'Content-Type': 'application/json' },
  body: JSON.stringify({ email: 'demo@weatherlux.com', password: 'Demo1234!' })
});
const { accessToken } = await res.json();

// Requests autenticadas
const weather = await fetch('https://localhost:7001/api/weather?city=Bogotá', {
  headers: { 'Authorization': `Bearer ${accessToken}` }
});
```

---

## 📦 Paquetes NuGet

| Paquete                                       | Uso                    |
|-----------------------------------------------|------------------------|
| `MongoDB.Driver 2.28`                         | Base de datos          |
| `BCrypt.Net-Next 4.0`                         | Hash de contraseñas    |
| `Microsoft.AspNetCore.Authentication.JwtBearer 8.0` | Autenticación JWT |
| `Swashbuckle.AspNetCore 6.5`                  | Swagger / OpenAPI      |

---

## ⚙️ Variables de Entorno (Producción)

```bash
MONGODB__CONNECTIONSTRING=mongodb+srv://...
JWT__SECRET=clave_muy_segura_minimo_32_caracteres
ASPNETCORE_ENVIRONMENT=Production
```
