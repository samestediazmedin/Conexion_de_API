using Microsoft.Extensions.Options;
using MongoDB.Driver;
using WeatherLux.Infrastructure.Database.Models;

namespace WeatherLux.Infrastructure.Database.Configuration;

// ════════════════════════════════════════════════════════
//  SETTINGS
// ════════════════════════════════════════════════════════
public class MongoDbSettings
{
    public string ConnectionString { get; set; } = "mongodb://localhost:27017";
    public string DatabaseName     { get; set; } = "weatherlux_db";
}

// ════════════════════════════════════════════════════════
//  DB CONTEXT
// ════════════════════════════════════════════════════════
public class WeatherLuxDbContext
{
    private readonly IMongoDatabase _db;

    public WeatherLuxDbContext(IOptions<MongoDbSettings> options)
    {
        var settings = MongoClientSettings.FromConnectionString(options.Value.ConnectionString);
        settings.ServerApi = new ServerApi(ServerApiVersion.V1);

        var client = new MongoClient(settings);
        _db = client.GetDatabase(options.Value.DatabaseName);
    }

    // ── Colecciones ───────────────────────────────────────
    public IMongoCollection<UserDocument>          Users         => Col<UserDocument>("users");
    public IMongoCollection<SearchHistoryDocument> SearchHistory => Col<SearchHistoryDocument>("search_history");
    public IMongoCollection<WeatherCacheDocument>  WeatherCache  => Col<WeatherCacheDocument>("weather_cache");
    public IMongoCollection<WeatherAlertDocument>  WeatherAlerts => Col<WeatherAlertDocument>("weather_alerts");
    public IMongoCollection<ApiLogDocument>        ApiLogs       => Col<ApiLogDocument>("api_logs");

    public IMongoDatabase Database => _db;

    private IMongoCollection<T> Col<T>(string name) => _db.GetCollection<T>(name);
}

// ════════════════════════════════════════════════════════
//  INICIALIZADOR DE ÍNDICES
//  Ejecutar una vez al iniciar la app
// ════════════════════════════════════════════════════════
public class MongoDbInitializer
{
    private readonly WeatherLuxDbContext _ctx;
    private readonly ILogger<MongoDbInitializer> _logger;

    public MongoDbInitializer(WeatherLuxDbContext ctx, ILogger<MongoDbInitializer> logger)
    {
        _ctx    = ctx;
        _logger = logger;
    }

    public async Task InitializeAsync()
    {
        _logger.LogInformation("🗄️  Inicializando índices MongoDB...");
        try
        {
            await CreateUsersIndexesAsync();
            await CreateSearchHistoryIndexesAsync();
            await CreateWeatherCacheIndexesAsync();
            await CreateWeatherAlertsIndexesAsync();
            await CreateApiLogsIndexesAsync();
            _logger.LogInformation("✅ Todos los índices creados correctamente");
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "❌ Error creando índices MongoDB");
            throw;
        }
    }

    // ── users ────────────────────────────────────────────
    private async Task CreateUsersIndexesAsync()
    {
        var col = _ctx.Users;
        await col.Indexes.CreateManyAsync(new[]
        {
            // Email único — clave de login
            new CreateIndexModel<UserDocument>(
                Builders<UserDocument>.IndexKeys.Ascending(u => u.Email),
                new CreateIndexOptions { Unique = true, Name = "idx_users_email_unique" }),

            // Búsquedas por rol (admin queries)
            new CreateIndexModel<UserDocument>(
                Builders<UserDocument>.IndexKeys.Ascending(u => u.Role),
                new CreateIndexOptions { Name = "idx_users_role" }),

            // Usuarios activos
            new CreateIndexModel<UserDocument>(
                Builders<UserDocument>.IndexKeys.Ascending(u => u.IsActive),
                new CreateIndexOptions { Name = "idx_users_isActive" }),
        });
        _logger.LogDebug("   ✓ users indexes");
    }

    // ── search_history ───────────────────────────────────
    private async Task CreateSearchHistoryIndexesAsync()
    {
        var col = _ctx.SearchHistory;
        await col.Indexes.CreateManyAsync(new[]
        {
            // Historial de usuario ordenado por fecha DESC
            new CreateIndexModel<SearchHistoryDocument>(
                Builders<SearchHistoryDocument>.IndexKeys
                    .Ascending(s => s.UserId)
                    .Descending(s => s.SearchedAt),
                new CreateIndexOptions { Name = "idx_history_user_date" }),

            // Ciudades más buscadas (aggregation pipeline)
            new CreateIndexModel<SearchHistoryDocument>(
                Builders<SearchHistoryDocument>.IndexKeys.Ascending(s => s.City),
                new CreateIndexOptions { Name = "idx_history_city" }),

            // TTL: búsquedas ANÓNIMAS se borran después de 7 días
            new CreateIndexModel<SearchHistoryDocument>(
                Builders<SearchHistoryDocument>.IndexKeys.Ascending(s => s.SearchedAt),
                new CreateIndexOptions
                {
                    Name        = "idx_history_ttl_anon_7d",
                    ExpireAfter = TimeSpan.FromDays(7),
                    PartialFilterExpression =
                        Builders<SearchHistoryDocument>.Filter.Eq(s => s.UserId, null)
                }),
        });
        _logger.LogDebug("   ✓ search_history indexes");
    }

    // ── weather_cache ────────────────────────────────────
    private async Task CreateWeatherCacheIndexesAsync()
    {
        var col = _ctx.WeatherCache;
        await col.Indexes.CreateManyAsync(new[]
        {
            // Lookup O(1) por clave de cache
            new CreateIndexModel<WeatherCacheDocument>(
                Builders<WeatherCacheDocument>.IndexKeys.Ascending(c => c.CacheKey),
                new CreateIndexOptions { Unique = true, Name = "idx_cache_key_unique" }),

            // TTL: MongoDB borra el doc cuando expiresAt <= ahora
            new CreateIndexModel<WeatherCacheDocument>(
                Builders<WeatherCacheDocument>.IndexKeys.Ascending(c => c.ExpiresAt),
                new CreateIndexOptions { ExpireAfter = TimeSpan.Zero, Name = "idx_cache_ttl_30m" }),
        });
        _logger.LogDebug("   ✓ weather_cache indexes");
    }

    // ── weather_alerts ───────────────────────────────────
    private async Task CreateWeatherAlertsIndexesAsync()
    {
        var col = _ctx.WeatherAlerts;
        await col.Indexes.CreateManyAsync(new[]
        {
            // Alertas activas de un usuario
            new CreateIndexModel<WeatherAlertDocument>(
                Builders<WeatherAlertDocument>.IndexKeys
                    .Ascending(a => a.UserId)
                    .Ascending(a => a.IsActive),
                new CreateIndexOptions { Name = "idx_alerts_user_active" }),
        });
        _logger.LogDebug("   ✓ weather_alerts indexes");
    }

    // ── api_logs ─────────────────────────────────────────
    private async Task CreateApiLogsIndexesAsync()
    {
        var col = _ctx.ApiLogs;
        await col.Indexes.CreateManyAsync(new[]
        {
            // Dashboard de métricas (ordenado por fecha)
            new CreateIndexModel<ApiLogDocument>(
                Builders<ApiLogDocument>.IndexKeys.Descending(l => l.RequestedAt),
                new CreateIndexOptions { Name = "idx_logs_date_desc" }),

            // Filtrar por endpoint
            new CreateIndexModel<ApiLogDocument>(
                Builders<ApiLogDocument>.IndexKeys.Ascending(l => l.Endpoint),
                new CreateIndexOptions { Name = "idx_logs_endpoint" }),

            // TTL: logs se borran automáticamente después de 30 días
            new CreateIndexModel<ApiLogDocument>(
                Builders<ApiLogDocument>.IndexKeys.Ascending(l => l.RequestedAt),
                new CreateIndexOptions { ExpireAfter = TimeSpan.FromDays(30), Name = "idx_logs_ttl_30d" }),
        });
        _logger.LogDebug("   ✓ api_logs indexes");
    }
}
